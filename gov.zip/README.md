# Portal de Demonstração

Projeto estático pronto para hospedagem na Vercel.

## Publicação

1. Extraia o ZIP.
2. Entre na Vercel.
3. Importe a pasta/projeto.
4. Framework: Other / projeto estático.
5. Build Command: deixe vazio.
6. Output Directory: `.`

O projeto não depende de backend.
